package com.example.rchen.stateandcapital;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.DataInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class MainActivity extends Activity
{

    //instantiate the items in view
    public EditText inputStateOrCapital;
    public TextView outputCorrespondingStateOrCapital;
    public Button go, cancel;

    private static final String FILENAME = "US_states";
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connect items in view to controller
        outputCorrespondingStateOrCapital = (TextView) findViewById(R.id.textView1);
        inputStateOrCapital = (EditText) findViewById(R.id.editText1);
        go = (Button) findViewById(R.id.buttonGo);
        cancel = (Button) findViewById(R.id.buttonCancel);

        //create database
        SQLiteDatabase db = openOrCreateDatabase("stateandcapitaldb.db", MODE_PRIVATE, null);

        db.execSQL("create table if not exists statetable(_id integer primary key autoincrement, state text, capital text)");
        Cursor c = db.rawQuery("select * from statetable", null);

        //if Cursor found no data in database fill it with states
        if (c.getCount() == 0)
        {
            //Store States and Capitals From text file to array
            String states[] = new String[50];
            String capitals[] = new String[50];
            parseUSStates(states, capitals);

            //Store States and Capital From array into Sqlite database
            for (int i = 0; i < states.length; i++)
            {
                ContentValues cv = new ContentValues();
                cv.put("state", states[i]);
                cv.put("capital", capitals[i]);
                long record_id = db.insert("statetable", null, cv);
            }

        }
        c.close();
        db.close();
    }


    //****************************parseUSStates()*****************************
    //Retrieved from Abbas Moghtanei's Hills as a helper method to get state and capitals
    private void parseUSStates(String states[], String capitals[])
    {
        try
        {
            //learned to read text file from assests folder using the following link
            //https://stackoverflow.com/questions/10982252/android-reading-a-file-using-scanner-
            // how-to-get-to-the-file?utm_medium=organic&utm_source=google_rich_qa&utm_campaign=google_rich_qa
            DataInputStream textFileStream = new DataInputStream(getAssets().open(String.format(FILENAME)));
            Scanner sc = new Scanner(textFileStream);
            String line;
            int i = 0;

            sc.nextLine(); sc.nextLine(); // skip over couple of headers

            while(sc.hasNext())
            {
                line = sc.nextLine();
                String temp[] = line.split("\\s\\s+");
                if(temp.length >= 2)
                {
                    if(temp.length == 2)
                    {
                        states[i]     = temp[0];
                        capitals[i++] = temp[1];
                    }
                    else
                    {
                        states[i]     = temp[0] + " " + temp[1];
                        capitals[i++] = temp[2];
                    }
                }
            }

        }catch(FileNotFoundException e){System.err.println(e);} catch (IOException e) {
            e.printStackTrace();
        }
    }

    //***************************go()***********************************************
    //Provides functionality for go button onClick method.
    //Gets Capital When State is input and Gets State When Capital is input.
    public void go(View view)
    {
        SQLiteDatabase db = openOrCreateDatabase("stateandcapitaldb.db", MODE_PRIVATE, null);;
        String input = inputStateOrCapital.getText().toString();
        Cursor c = db.rawQuery("select * from statetable", null);

        while (c.moveToNext())
        {
            if(c.getString(1).trim().equalsIgnoreCase(input))
            {
                outputCorrespondingStateOrCapital.setText(c.getString(2));
                break;
            }
            else if(c.getString(2).trim().equalsIgnoreCase(input))
            {
                outputCorrespondingStateOrCapital.setText(c.getString(1));
                break;
            }
            else
            {
                outputCorrespondingStateOrCapital.setText("No State, Nor Capital");
            }
        }

        c.close();
        db.close();
    }

    //*******************************cancel()*******************************************
    //Removes Text from EditText field
    public void cancel (View view)
    {
        inputStateOrCapital.setText("");
    }

    //********************remove_activity_title()*****************************
    public void remove_actvity_title(Activity activity)
    {
        activity.requestWindowFeature(Window.FEATURE_NO_TITLE);
    }

}